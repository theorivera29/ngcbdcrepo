DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `accounts_id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_fname` varchar(45) NOT NULL,
  `accounts_lname` varchar(45) NOT NULL,
  `accounts_username` varchar(45) NOT NULL,
  `accounts_password` varchar(150) NOT NULL,
  `accounts_type` varchar(45) NOT NULL,
  `accounts_email` varchar(45) NOT NULL,
  `accounts_deletable` varchar(45) NOT NULL,
  `accounts_status` varchar(45) NOT NULL,
  PRIMARY KEY (`accounts_id`),
  UNIQUE KEY `accounts_id_UNIQUE` (`accounts_id`),
  UNIQUE KEY `accounts_username_UNIQUE` (`accounts_username`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
LOCK TABLES `accounts` WRITE;
INSERT INTO `accounts` VALUES (1,'Materials','Engineer','materials_engineer','$2y$10$9KWB6zo6BUhC2U9qWyIkJuwfLMDK6GnoctpYbaxCpT4IuBYHyUjZy','Materials Engineer','mateng@gmail.com','no','active'),(2,'Admin','Account','admin','$2y$10$7MiO1behDuzQBbUdNL1riOjO7eDnOIcbL2J4DWIvec/cRMCZduRCm','Admin','admin@gmail.com','no','active'),(3,'View','Only','view_only','$2y$10$xkl8OZp95hIZNkSUfKul5.wYUVZvNDJK12PdMrhmO285A8ogM6/c2','View Only','viewonly@gmail.com','no','active');
UNLOCK TABLES;
DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `projects_id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_name` varchar(45) NOT NULL,
  `projects_address` varchar(50) NOT NULL,
  `projects_sdate` date NOT NULL,
  `projects_edate` date NOT NULL,
  `projects_status` varchar(45) NOT NULL,
  PRIMARY KEY (`projects_id`),
  UNIQUE KEY `projects_id_UNIQUE` (`projects_id`),
  UNIQUE KEY `projects_name_UNIQUE` (`projects_name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
LOCK TABLES `projects` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_name` varchar(45) NOT NULL,
  PRIMARY KEY (`categories_id`),
  UNIQUE KEY `categories_id_UNIQUE` (`categories_id`),
  UNIQUE KEY `categories_name_UNIQUE` (`categories_name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
LOCK TABLES `categories` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `catproj`;
CREATE TABLE `catproj` (
  `catproj_project` int(11) NOT NULL,
  `catproj_categories` int(11) NOT NULL,
  KEY `catproj_proj_idx` (`catproj_project`),
  KEY `catproj_categ_idx` (`catproj_categories`),
  CONSTRAINT `catproj_categ` FOREIGN KEY (`catproj_categories`) REFERENCES `categories` (`categories_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `catproj_proj` FOREIGN KEY (`catproj_project`) REFERENCES `projects` (`projects_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES `catproj` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `unit`;
CREATE TABLE `unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(45) NOT NULL,
  PRIMARY KEY (`unit_id`),
  UNIQUE KEY `unit_id_UNIQUE` (`unit_id`),
  UNIQUE KEY `unit_name_UNIQUE` (`unit_name`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
LOCK TABLES `unit` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `materials`;
CREATE TABLE `materials` (
  `mat_id` int(11) NOT NULL AUTO_INCREMENT,
  `mat_name` varchar(65) NOT NULL,
  `mat_categ` int(11) NOT NULL,
  `mat_unit` int(11) NOT NULL,
  PRIMARY KEY (`mat_id`),
  UNIQUE KEY `mat_id_UNIQUE` (`mat_id`),
  UNIQUE KEY `mat_name_UNIQUE` (`mat_name`),
  KEY `matcateg_idx` (`mat_categ`),
  KEY `matunit_idx` (`mat_unit`),
  CONSTRAINT `matcateg` FOREIGN KEY (`mat_categ`) REFERENCES `categories` (`categories_id`) ON UPDATE CASCADE,
  CONSTRAINT `matunit` FOREIGN KEY (`mat_unit`) REFERENCES `unit` (`unit_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=319 DEFAULT CHARSET=latin1;
LOCK TABLES `materials` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `matinfo`;
CREATE TABLE `matinfo` (
  `matinfo_id` int(11) NOT NULL AUTO_INCREMENT,
  `matinfo_prevStock` int(11) NOT NULL,
  `matinfo_project` int(11) NOT NULL,
  `matinfo_notif` varchar(45) NOT NULL,
  `currentQuantity` varchar(45) NOT NULL,
  `matinfo_matname` int(11) NOT NULL,
  PRIMARY KEY (`matinfo_id`),
  UNIQUE KEY `matinfo_id_UNIQUE` (`matinfo_id`),
  KEY `matname_idx` (`matinfo_matname`),
  KEY `matproject_idx` (`matinfo_project`),
  CONSTRAINT `matname` FOREIGN KEY (`matinfo_matname`) REFERENCES `materials` (`mat_id`) ON UPDATE CASCADE,
  CONSTRAINT `matproject` FOREIGN KEY (`matinfo_project`) REFERENCES `projects` (`projects_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
LOCK TABLES `matinfo` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `hauling`;
CREATE TABLE `hauling` (
  `hauling_id` int(11) NOT NULL AUTO_INCREMENT,
  `hauling_no` int(11) NOT NULL,
  `hauling_date` date NOT NULL,
  `hauling_deliverTo` varchar(45) NOT NULL,
  `hauling_hauledFrom` int(11) NOT NULL,
  `hauling_hauledBy` varchar(45) NOT NULL,
  `hauling_requestedBy` varchar(45) NOT NULL,
  `hauling_warehouseman` varchar(45) NOT NULL,
  `hauling_approvedBy` varchar(45) NOT NULL,
  `hauling_truckDetailsType` varchar(45) NOT NULL,
  `hauling_truckDetailsPlateNo` varchar(45) NOT NULL,
  `hauling_truckDetailsPO` varchar(45) NOT NULL,
  `hauling_truckDetailsHaulerDR` varchar(45) NOT NULL,
  `hauling_status` varchar(45) NOT NULL,
  PRIMARY KEY (`hauling_id`),
  UNIQUE KEY `hauling_id_UNIQUE` (`hauling_id`),
  UNIQUE KEY `hauling_no_UNIQUE` (`hauling_no`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
LOCK TABLES `hauling` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `haulingmat`;
CREATE TABLE `haulingmat` (
  `haulingmat_id` int(11) NOT NULL AUTO_INCREMENT,
  `haulingmat_haulingid` int(11) NOT NULL,
  `haulingmat_matname` int(11) NOT NULL,
  `haulingmat_qty` int(11) NOT NULL,
  `haulingmat_unit` int(11) NOT NULL,
  PRIMARY KEY (`haulingmat_id`),
  UNIQUE KEY `haulingmat_id_UNIQUE` (`haulingmat_id`),
  KEY `haulingmatname_idx` (`haulingmat_matname`),
  KEY `haulingunit_idx` (`haulingmat_unit`),
  KEY `haulingid_idx` (`haulingmat_haulingid`),
  CONSTRAINT `haulingid` FOREIGN KEY (`haulingmat_haulingid`) REFERENCES `hauling` (`hauling_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `haulingmatname` FOREIGN KEY (`haulingmat_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `haulingunit` FOREIGN KEY (`haulingmat_unit`) REFERENCES `unit` (`unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
LOCK TABLES `haulingmat` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `lastmatinfo`;
CREATE TABLE `lastmatinfo` (
  `lastmatinfo_id` int(11) NOT NULL AUTO_INCREMENT,
  `lastmatinfo_matname` int(11) NOT NULL,
  `lastmatinfo_categ` int(11) NOT NULL,
  `lastmatinfo_prevStock` int(11) NOT NULL,
  `lastmatinfo_unit` int(11) NOT NULL,
  `lastmatinfo_deliveredMat` int(11) NOT NULL,
  `lastmatinfo_matPulledOut` int(11) NOT NULL,
  `lastmatinfo_accumulatedMat` int(11) NOT NULL,
  `lastmatinfo_matOnSite` int(11) NOT NULL,
  `lastmatinfo_project` int(11) NOT NULL,
  `lastmatinfo_year` int(11) NOT NULL,
  `lastmatinfo_month` int(11) NOT NULL,
  PRIMARY KEY (`lastmatinfo_id`),
  UNIQUE KEY `lastmatinfo_id_UNIQUE` (`lastmatinfo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
LOCK TABLES `lastmatinfo` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `logs_id` int(11) NOT NULL AUTO_INCREMENT,
  `logs_datetime` datetime NOT NULL,
  `logs_activity` varchar(255) NOT NULL,
  `logs_logsOf` int(11) NOT NULL,
  PRIMARY KEY (`logs_id`),
  UNIQUE KEY `logs_id_UNIQUE` (`logs_id`),
  KEY `logsmateng_idx` (`logs_logsOf`),
  CONSTRAINT `logsmateng` FOREIGN KEY (`logs_logsOf`) REFERENCES `accounts` (`accounts_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `logs` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `projmateng`;
CREATE TABLE `projmateng` (
  `projmateng_id` int(11) NOT NULL AUTO_INCREMENT,
  `projmateng_project` int(11) NOT NULL,
  `projmateng_mateng` int(11) NOT NULL,
  PRIMARY KEY (`projmateng_id`),
  UNIQUE KEY `projacc_id_UNIQUE` (`projmateng_id`),
  KEY `projmateng_of_idx` (`projmateng_mateng`),
  KEY `projmateng_proj_idx` (`projmateng_project`),
  CONSTRAINT `projmateng_of` FOREIGN KEY (`projmateng_mateng`) REFERENCES `accounts` (`accounts_id`) ON UPDATE CASCADE,
  CONSTRAINT `projmateng_proj` FOREIGN KEY (`projmateng_project`) REFERENCES `projects` (`projects_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
LOCK TABLES `projmateng` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `request`;
CREATE TABLE `request` (
  `req_id` int(11) NOT NULL AUTO_INCREMENT,
  `req_username` int(11) NOT NULL,
  `req_date` date NOT NULL,
  `req_status` varchar(45) NOT NULL,
  PRIMARY KEY (`req_id`),
  UNIQUE KEY `req_id_UNIQUE` (`req_id`),
  KEY `req_uname_idx` (`req_username`),
  CONSTRAINT `req_uname` FOREIGN KEY (`req_username`) REFERENCES `accounts` (`accounts_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `request` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `requisition`;
CREATE TABLE `requisition` (
  `requisition_id` int(11) NOT NULL AUTO_INCREMENT,
  `requisition_no` int(11) NOT NULL,
  `requisition_date` date NOT NULL,
  `requisition_remarks` varchar(65) NOT NULL,
  `requisition_reqBy` varchar(45) NOT NULL,
  `requisition_approvedBy` varchar(45) NOT NULL,
  `requisition_project` int(11) NOT NULL,
  PRIMARY KEY (`requisition_id`),
  UNIQUE KEY `requisition_id_UNIQUE` (`requisition_id`),
  UNIQUE KEY `requisition_no_UNIQUE` (`requisition_no`),
  KEY `reqproj_idx` (`requisition_project`),
  CONSTRAINT `reqproj` FOREIGN KEY (`requisition_project`) REFERENCES `projects` (`projects_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `requisition` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reqmaterial`;
CREATE TABLE `reqmaterial` (
  `reqmaterial_id` int(11) NOT NULL AUTO_INCREMENT,
  `reqmaterial_requisition` int(11) NOT NULL,
  `reqmaterial_material` int(11) NOT NULL,
  `reqmaterial_qty` int(11) NOT NULL,
  `reqmaterial_areaOfUsage` varchar(45) NOT NULL,
  PRIMARY KEY (`reqmaterial_id`),
  UNIQUE KEY `reqmaterial_id_UNIQUE` (`reqmaterial_id`),
  KEY `reqmaterialrequisition_idx` (`reqmaterial_requisition`),
  KEY `reqmaterialmaterial_idx` (`reqmaterial_material`),
  CONSTRAINT `reqmaterialmaterial` FOREIGN KEY (`reqmaterial_material`) REFERENCES `materials` (`mat_id`) ON UPDATE CASCADE,
  CONSTRAINT `reqmaterialrequisition` FOREIGN KEY (`reqmaterial_requisition`) REFERENCES `requisition` (`requisition_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
LOCK TABLES `reqmaterial` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `returns`;
CREATE TABLE `returns` (
  `returns_id` int(11) NOT NULL AUTO_INCREMENT,
  `returns_hauling_no` int(11) NOT NULL,
  `returns_matname` int(11) NOT NULL,
  `returns_status` varchar(45) NOT NULL,
  PRIMARY KEY (`returns_id`),
  UNIQUE KEY `returns_id_UNIQUE` (`returns_id`),
  KEY `returnsmatname_idx` (`returns_matname`),
  KEY `returnshaulingno_idx` (`returns_hauling_no`),
  CONSTRAINT `returnshaulingno` FOREIGN KEY (`returns_hauling_no`) REFERENCES `hauling` (`hauling_no`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `returnsmatname` FOREIGN KEY (`returns_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
LOCK TABLES `returns` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `returnhistory`;
CREATE TABLE `returnhistory` (
  `returnhistory_id` int(11) NOT NULL AUTO_INCREMENT,
  `returns_id` int(11) NOT NULL,
  `returnhistory_date` date NOT NULL,
  `returnhistory_returningqty` int(11) NOT NULL,
  PRIMARY KEY (`returnhistory_id`),
  UNIQUE KEY `returnHistory_id_UNIQUE` (`returnhistory_id`),
  KEY `returnhistoryMatname_idx` (`returns_id`),
  CONSTRAINT `returnhistoryMatname` FOREIGN KEY (`returns_id`) REFERENCES `returns` (`returns_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
LOCK TABLES `returnhistory` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `todo`;
CREATE TABLE `todo` (
  `todo_id` int(11) NOT NULL AUTO_INCREMENT,
  `todo_date` date NOT NULL,
  `todo_task` varchar(51) NOT NULL,
  `todo_status` varchar(45) NOT NULL,
  `todoOf` int(11) NOT NULL,
  PRIMARY KEY (`todo_id`),
  UNIQUE KEY `todo_id_UNIQUE` (`todo_id`),
  KEY `todo_of_idx` (`todoOf`),
  CONSTRAINT `todo_of` FOREIGN KEY (`todoOf`) REFERENCES `accounts` (`accounts_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `todo` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `usagein`;
CREATE TABLE `usagein` (
  `usagein_id` int(11) NOT NULL AUTO_INCREMENT,
  `usagein_date` date NOT NULL,
  `usagein_quantity` varchar(45) NOT NULL,
  `pulledOutBy` varchar(45) NOT NULL,
  `usagein_areaOfUsage` varchar(45) NOT NULL,
  `usagein_material` int(11) NOT NULL,
  `usagein_project` int(11) NOT NULL,
  PRIMARY KEY (`usagein_id`),
  UNIQUE KEY `usagein_id_UNIQUE` (`usagein_id`),
  KEY `usagematname_idx` (`usagein_material`),
  KEY `usageproject_idx` (`usagein_project`),
  CONSTRAINT `usagematerial` FOREIGN KEY (`usagein_material`) REFERENCES `materials` (`mat_id`) ON UPDATE CASCADE,
  CONSTRAINT `usageproject` FOREIGN KEY (`usagein_project`) REFERENCES `matinfo` (`matinfo_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
LOCK TABLES `usagein` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `deliveredin`;
CREATE TABLE `deliveredin` (
  `deliveredin_id` int(11) NOT NULL AUTO_INCREMENT,
  `deliveredin_date` date NOT NULL,
  `deliveredin_remarks` varchar(45) NOT NULL,
  `deliveredin_receiptno` varchar(45) NOT NULL,
  `deliveredin_project` int(11) NOT NULL,
  PRIMARY KEY (`deliveredin_id`),
  UNIQUE KEY `deliveredin_id_UNIQUE` (`deliveredin_id`),
  UNIQUE KEY `deliveredin_receiptno_UNIQUE` (`deliveredin_receiptno`),
  KEY `delivproj_idx` (`deliveredin_project`),
  CONSTRAINT `delivproj` FOREIGN KEY (`deliveredin_project`) REFERENCES `projects` (`projects_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
LOCK TABLES `deliveredin` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `deliveredmat`;
CREATE TABLE `deliveredmat` (
  `deliveredmat_id` int(11) NOT NULL AUTO_INCREMENT,
  `deliveredmat_deliveredin` int(11) NOT NULL,
  `deliveredmat_materials` int(11) NOT NULL,
  `deliveredmat_qty` int(11) NOT NULL,
  `suppliedBy` varchar(45) NOT NULL,
  PRIMARY KEY (`deliveredmat_id`),
  UNIQUE KEY `deliveredmat_id_UNIQUE` (`deliveredmat_id`),
  KEY `deliveredin_idx` (`deliveredmat_deliveredin`),
  KEY `deliveredinmat_idx` (`deliveredmat_materials`),
  CONSTRAINT `deliveredin` FOREIGN KEY (`deliveredmat_deliveredin`) REFERENCES `deliveredin` (`deliveredin_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `deliveredinmat` FOREIGN KEY (`deliveredmat_materials`) REFERENCES `materials` (`mat_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
LOCK TABLES `deliveredmat` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `disposal`;
CREATE TABLE `disposal` (
  `disposal_id` int(11) NOT NULL AUTO_INCREMENT,
  `disposal_date` date NOT NULL,
  `disposal_qty` int(11) NOT NULL,
  `disposal_matname` int(11) NOT NULL,
  `disposal_remarks` varchar(65) NOT NULL,
  PRIMARY KEY (`disposal_id`),
  UNIQUE KEY `disposal_id_UNIQUE` (`disposal_id`),
  KEY `disposalmatname_idx` (`disposal_matname`),
  CONSTRAINT `disposalmatname` FOREIGN KEY (`disposal_matname`) REFERENCES `materials` (`mat_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
LOCK TABLES `disposal` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reconciliation`;
CREATE TABLE `reconciliation` (
  `reconciliation_id` int(11) NOT NULL AUTO_INCREMENT,
  `reconciliation_physCount` int(11) NOT NULL,
  `reconciliation_matinfo` int(11) NOT NULL,
  `reconciliation_remarks` varchar(65) DEFAULT NULL,
  PRIMARY KEY (`reconciliation_id`),
  UNIQUE KEY `reconciliation_id_UNIQUE` (`reconciliation_id`),
  KEY `reconciliationsyscount_idx` (`reconciliation_matinfo`),
  CONSTRAINT `reconciliationsyscount` FOREIGN KEY (`reconciliation_matinfo`) REFERENCES `matinfo` (`matinfo_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
LOCK TABLES `reconciliation` WRITE;
UNLOCK TABLES;